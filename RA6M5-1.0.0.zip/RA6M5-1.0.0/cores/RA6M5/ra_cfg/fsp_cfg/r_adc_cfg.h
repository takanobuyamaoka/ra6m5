/* generated configuration header file - do not edit */
#ifndef R_ADC_CFG_H_
#define R_ADC_CFG_H_
#define ADC_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#endif /* R_ADC_CFG_H_ */
