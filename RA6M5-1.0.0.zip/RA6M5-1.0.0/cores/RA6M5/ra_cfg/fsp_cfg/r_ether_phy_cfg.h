/* generated configuration header file - do not edit */
#ifndef R_ETHER_PHY_CFG_H_
#define R_ETHER_PHY_CFG_H_
#define ETHER_PHY_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#define ETHER_PHY_CFG_USE_PHY (3)
#define ETHER_PHY_CFG_USE_REF_CLK (1)
#endif /* R_ETHER_PHY_CFG_H_ */
