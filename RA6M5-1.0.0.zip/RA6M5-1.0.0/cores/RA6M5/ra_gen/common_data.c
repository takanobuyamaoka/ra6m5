/* generated common source file - do not edit */
#include "common_data.h"

ioport_instance_ctrl_t g_ioport_ctrl;
const ioport_instance_t g_ioport = { .p_api = &g_ioport_on_ioport, .p_ctrl =
		&g_ioport_ctrl, .p_cfg = &g_bsp_pin_cfg, };
ether_phy_instance_ctrl_t g_ether_phy0_ctrl;

const ether_phy_cfg_t g_ether_phy0_cfg = {

.channel = 0, .phy_lsi_address = 1, .phy_reset_wait_time = 0x00020000,
		.mii_bit_access_wait_time = 8, .flow_control =
				ETHER_PHY_FLOW_CONTROL_DISABLE, .mii_type =
				ETHER_PHY_MII_TYPE_MII, .p_context = NULL, .p_extend = NULL,

};
/* Instance structure to use this module. */
const ether_phy_instance_t g_ether_phy0 = { .p_ctrl = &g_ether_phy0_ctrl,
		.p_cfg = &g_ether_phy0_cfg, .p_api = &g_ether_phy_on_ether_phy };
ether_instance_ctrl_t g_ether0_ctrl;

uint8_t g_ether0_mac_address[6] = { 0x00, 0x11, 0x22, 0x33, 0x44, 0x55 };

__attribute__((__aligned__(16))) ether_instance_descriptor_t g_ether0_tx_descriptors[8] ETHER_BUFFER_PLACE_IN_SECTION;
__attribute__((__aligned__(16))) ether_instance_descriptor_t g_ether0_rx_descriptors[8] ETHER_BUFFER_PLACE_IN_SECTION;

__attribute__((__aligned__(32)))uint8_t g_ether0_ether_buffer0[1536]ETHER_BUFFER_PLACE_IN_SECTION;
__attribute__((__aligned__(32)))uint8_t g_ether0_ether_buffer1[1536]ETHER_BUFFER_PLACE_IN_SECTION;
__attribute__((__aligned__(32)))uint8_t g_ether0_ether_buffer2[1536]ETHER_BUFFER_PLACE_IN_SECTION;
__attribute__((__aligned__(32)))uint8_t g_ether0_ether_buffer3[1536]ETHER_BUFFER_PLACE_IN_SECTION;
__attribute__((__aligned__(32)))uint8_t g_ether0_ether_buffer4[1536]ETHER_BUFFER_PLACE_IN_SECTION;
__attribute__((__aligned__(32)))uint8_t g_ether0_ether_buffer5[1536]ETHER_BUFFER_PLACE_IN_SECTION;
__attribute__((__aligned__(32)))uint8_t g_ether0_ether_buffer6[1536]ETHER_BUFFER_PLACE_IN_SECTION;
__attribute__((__aligned__(32)))uint8_t g_ether0_ether_buffer7[1536]ETHER_BUFFER_PLACE_IN_SECTION;
__attribute__((__aligned__(32)))uint8_t g_ether0_ether_buffer8[1536]ETHER_BUFFER_PLACE_IN_SECTION;
__attribute__((__aligned__(32)))uint8_t g_ether0_ether_buffer9[1536]ETHER_BUFFER_PLACE_IN_SECTION;
__attribute__((__aligned__(32)))uint8_t g_ether0_ether_buffer10[1536]ETHER_BUFFER_PLACE_IN_SECTION;
__attribute__((__aligned__(32)))uint8_t g_ether0_ether_buffer11[1536]ETHER_BUFFER_PLACE_IN_SECTION;
__attribute__((__aligned__(32)))uint8_t g_ether0_ether_buffer12[1536]ETHER_BUFFER_PLACE_IN_SECTION;
__attribute__((__aligned__(32)))uint8_t g_ether0_ether_buffer13[1536]ETHER_BUFFER_PLACE_IN_SECTION;
__attribute__((__aligned__(32)))uint8_t g_ether0_ether_buffer14[1536]ETHER_BUFFER_PLACE_IN_SECTION;
__attribute__((__aligned__(32)))uint8_t g_ether0_ether_buffer15[1536]ETHER_BUFFER_PLACE_IN_SECTION;

uint8_t *pp_g_ether0_ether_buffers[16] = {
		(uint8_t*) &g_ether0_ether_buffer0[0],
		(uint8_t*) &g_ether0_ether_buffer1[0],
		(uint8_t*) &g_ether0_ether_buffer2[0],
		(uint8_t*) &g_ether0_ether_buffer3[0],
		(uint8_t*) &g_ether0_ether_buffer4[0],
		(uint8_t*) &g_ether0_ether_buffer5[0],
		(uint8_t*) &g_ether0_ether_buffer6[0],
		(uint8_t*) &g_ether0_ether_buffer7[0],
		(uint8_t*) &g_ether0_ether_buffer8[0],
		(uint8_t*) &g_ether0_ether_buffer9[0],
		(uint8_t*) &g_ether0_ether_buffer10[0],
		(uint8_t*) &g_ether0_ether_buffer11[0],
		(uint8_t*) &g_ether0_ether_buffer12[0],
		(uint8_t*) &g_ether0_ether_buffer13[0],
		(uint8_t*) &g_ether0_ether_buffer14[0],
		(uint8_t*) &g_ether0_ether_buffer15[0], };

const ether_cfg_t g_ether0_cfg = { .channel = 0, .zerocopy =
		ETHER_ZEROCOPY_DISABLE, .multicast = ETHER_MULTICAST_ENABLE,
		.promiscuous = ETHER_PROMISCUOUS_DISABLE, .flow_control =
				ETHER_FLOW_CONTROL_DISABLE, .padding = ETHER_PADDING_DISABLE,
		.padding_offset = 1, .broadcast_filter = 0, .p_mac_address =
				g_ether0_mac_address,

		.p_rx_descriptors = g_ether0_rx_descriptors, .p_tx_descriptors =
				g_ether0_tx_descriptors,

		.num_tx_descriptors = 8, .num_rx_descriptors = 8,

		.pp_ether_buffers = pp_g_ether0_ether_buffers,

		.ether_buffer_size = 1536,

#if defined(VECTOR_NUMBER_EDMAC0_EINT)
                .irq                = VECTOR_NUMBER_EDMAC0_EINT,
#else
		.irq = FSP_INVALID_VECTOR,
#endif

		.interrupt_priority = (2),

		.p_callback = vEtherISRCallback, .p_ether_phy_instance = &g_ether_phy0,
		.p_context = NULL, .p_extend = NULL, };

/* Instance structure to use this module. */
const ether_instance_t g_ether0 = { .p_ctrl = &g_ether0_ctrl, .p_cfg =
		&g_ether0_cfg, .p_api = &g_ether_on_ether };
ether_instance_t const *gp_freertos_ether = &g_ether0;

QueueHandle_t g_usb_transaction_queue;
#if 1
StaticQueue_t g_usb_transaction_queue_memory;
uint8_t g_usb_transaction_queue_queue_memory[1 * 20];
#endif
void rtos_startup_err_callback(void *p_instance, void *p_data);
EventGroupHandle_t g_event_group;
#if 1
StaticEventGroup_t g_event_group_memory;
#endif
void rtos_startup_err_callback(void *p_instance, void *p_data);
EventGroupHandle_t g_update_console_event;
#if 1
StaticEventGroup_t g_update_console_event_memory;
#endif
void rtos_startup_err_callback(void *p_instance, void *p_data);
void g_common_init(void) {
	g_usb_transaction_queue =
#if 1
			xQueueCreateStatic(
#else
                xQueueCreate(
                #endif
					20, 1
#if 1
					, &g_usb_transaction_queue_queue_memory[0],
					&g_usb_transaction_queue_memory
#endif
					);
	if (NULL == g_usb_transaction_queue) {
		rtos_startup_err_callback(g_usb_transaction_queue, 0);
	}
	g_event_group =
#if 1
			xEventGroupCreateStatic(&g_event_group_memory);
#else
                xEventGroupCreate();
                #endif
	if (NULL == g_event_group) {
		rtos_startup_err_callback(g_event_group, 0);
	}
	g_update_console_event =
#if 1
			xEventGroupCreateStatic(&g_update_console_event_memory);
#else
                xEventGroupCreate();
                #endif
	if (NULL == g_update_console_event) {
		rtos_startup_err_callback(g_update_console_event, 0);
	}
}
